"""
若茗 PaaS - Alembic 迁移环境配置
Author: ruoming
"""
import asyncio
import os
import sys
from logging.config import fileConfig

from alembic import context
from sqlalchemy import pool, String, Text
from sqlalchemy.engine import Connection
from sqlalchemy.ext.asyncio import async_engine_from_config
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.types import TypeDecorator, CHAR

# 添加项目根目录到 PATH，使 app 包可以被导入
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


# ── pgvector 自定义类型（SQLAlchemy 不直接支持 pgvector）─────────────────────────
class Vector(TypeDecorator):
    """PostgreSQL pgvector 类型"""
    impl = CHAR
    cache_ok = True

    def __init__(self, dimension=1536):
        super().__init__(256 * dimension)  # 每个 float4 占 4 字节
        self.dimension = dimension

    def load_dialect_impl(self, dialect):
        return dialect.type_descriptor(String(256 * self.dimension))

    def process_bind_param(self, value, dialect):
        if value is not None:
            return '[' + ','.join([str(v) for v in value]) + ']'
        return value

    def process_result_value(self, value, dialect):
        if value is not None:
            return [float(x) for x in value.strip('[]').split(',')]
        return value

    def column_format(self, column, **kw):
        return f"VECTOR({self.dimension})"

from app.config import settings
from app.database import Base

# ── 导入所有模型（Alembic autogenerate 需要）────────────────────────────────
# 新增模块时，在此处补充导入，确保 autogenerate 能感知所有表变更

# 系统核心模块
from app.modules.user.models import SysUser, SysApiKey  # noqa: F401
from app.modules.tenant.models import SysTenant, SysTenantUsage  # noqa: F401
from app.modules.permission.models import (  # noqa: F401
    SysRole, SysPermission, SysColumnPermission,
    SysUserRole, SysRolePermission, SysUserPermission, SysRoleDept,
)
from app.modules.system.models import SysDept, SysDictType, SysDictItem, SysInitVersion  # noqa: F401
from app.modules.audit.models import SysAuditLog, SysLoginLog, SysSecurityEvent  # noqa: F401
from app.modules.config_center.models import SysConfig, SysConfigHistory  # noqa: F401
from app.modules.codegen.models import GenTable, GenTableColumn  # noqa: F401
from app.modules.customer_order3.models import CustomerOrder3  # noqa: F401
from app.modules.monitor.models import SysScheduledTask, SysTaskExecutionLog  # noqa: F401
from app.modules.message.models import SysNotice, SysUserMessage  # noqa: F401
from app.modules.file_center.models import SysFile  # noqa: F401
from app.modules.integration.models import (  # noqa: F401
    SysIntegrationConnection, SysExternalIdentity, SysContactSyncLog,
)

# AI 模块
from app.ai.llm.models import AiModelConfig  # noqa: F401
from app.ai.conversation.models import (  # noqa: F401
    AiConversation, AiMessage, AiEntityMemory, AiKeyValueMemory, AiCallLog,
)
from app.ai.agent.models import (  # noqa: F401
    AiAgent, AiSceneConfig,
    AiWorkflow, AiWorkflowVersion, AiWorkflowRun, AiWorkflowNodeRun,
)
from app.ai.knowledge.models import (  # noqa: F401
    AiKnowledgeBase, AiKnowledgeBaseShare, AiKnowledgeDoc, AiKnowledgeChunk,
    AiKnowledgeUploadPart, AiKnowledgeTask,
)
from app.ai.prompt.models import AiPromptTemplate, AiPromptVersion  # noqa: F401
from app.ai.tool.models import AiTool  # noqa: F401

# Alembic Config 对象
config = context.config

# 解释日志配置文件
if config.config_file_name is not None:
    fileConfig(config.config_file_name)

# 目标 Metadata（autogenerate 使用）
target_metadata = Base.metadata

# 从 Pydantic Settings 读取数据库 URL（同步连接，用于迁移）
# 注意：迁移用同步驱动，运行时用 asyncpg
db_url = settings.DATABASE_URL.replace(
    "postgresql+asyncpg://", "postgresql+psycopg2://"
)
config.set_main_option("sqlalchemy.url", db_url)


def run_migrations_offline() -> None:
    """离线模式（不需要数据库连接，只生成 SQL 脚本）"""
    url = config.get_main_option("sqlalchemy.url")
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
        compare_type=True,
        compare_server_default=True,
    )
    with context.begin_transaction():
        context.run_migrations()


def do_run_migrations(connection: Connection) -> None:
    context.configure(
        connection=connection,
        target_metadata=target_metadata,
        compare_type=True,
        compare_server_default=True,
    )
    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    """在线模式（连接数据库执行迁移）"""
    from sqlalchemy.engine import create_engine

    connectable = create_engine(
        config.get_main_option("sqlalchemy.url"),
        poolclass=pool.NullPool,
    )
    with connectable.connect() as connection:
        context.configure(
            connection=connection,
            target_metadata=target_metadata,
            compare_type=True,
            compare_server_default=True,
        )
        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
